import React from 'react';
import Paintings from './paintings';

function App () {
  return <div >
    <Paintings />
   </div >;
}

export default App;
