export const leftChild = [
    {
        "id": "1803782147722241",
        "nodeType": "KPI",
        "userName": "魏志宇",
        "userAvatar": {
            "color": null,
            "color_id": null,
            "content": null,
            "image": {
                "large": "https://s3-imfile.feishucdn.com/static-resource/v1/v2_c2342e1b-133e-4fa8-87f0-f8bf227766eg~?image_size=noop&cut_type=&quality=&format=image&sticker_format=.webp"
            },
            "source": "image"
        },
        "content": "111",
        "list": [
            {
                "_id": "1803794807899161",
                "basic_value": "22",
                "ceiling_value": "1111",
                "lowest_value": "2",
                "work_item_content": "反反复复付"
            }
        ],
        
        // 新增字段
        // alignType: 'forward',
    },
    {
        "id": "1803805678563366",
        "nodeType": "OKR",
        "userName": "魏志宇",
        "userAvatar": {
            "color": null,
            "color_id": null,
            "content": null,
            "image": {
                "large": "https://s3-imfile.feishucdn.com/static-resource/v1/v2_c2342e1b-133e-4fa8-87f0-f8bf227766eg~?image_size=noop&cut_type=&quality=&format=image&sticker_format=.webp"
            },
            "source": "image"
        },
        "content": "完成品宣阁XX家，完成XX的租赁堂食比门店XX%；",
        "list": [
            {
                "_id": "1803803245636700",
                "director": {
                    "avatar": {
                        "color": null,
                        "color_id": null,
                        "content": null,
                        "image": {
                            "large": "https://s3-imfile.feishucdn.com/static-resource/v1/v2_c2342e1b-133e-4fa8-87f0-f8bf227766eg~?image_size=noop&cut_type=&quality=&format=image&sticker_format=.webp"
                        },
                        "source": "image"
                    },
                    "i18n_name": [
                        {
                            "language_code": 2052,
                            "text": "魏志宇"
                        }
                    ],
                    "id": "1799583243652140",
                    "is_deleted": false,
                    "name": "魏志宇"
                },
                "synergies": [
                    {
                        "avatar": {
                            "color": null,
                            "color_id": null,
                            "content": null,
                            "image": {
                                "large": "https://s3-imfile.feishucdn.com/static-resource/v1/v3_007g_41528857-3b2e-466c-b764-0c8f8b8c469g~?image_size=noop&cut_type=&quality=&format=image&sticker_format=.webp"
                            },
                            "source": "image"
                        },
                        "i18n_name": [
                            {
                                "language_code": 2052,
                                "text": "司维坤"
                            }
                        ],
                        "id": "1799582925617267",
                        "is_deleted": false,
                        "name": "司维坤"
                    },
                    {
                        "avatar": {
                            "color": "#4871e9",
                            "color_id": null,
                            "content": null,
                            "image": {
                                "imageId": "825ca650d85448fb91257c84a09139e2_c",
                                "large": "/img/223537/825ca650d85448fb91257c84a09139e2_l.jpg"
                            },
                            "source": "image"
                        },
                        "i18n_name": [
                            {
                                "language_code": 2052,
                                "text": "管步哲"
                            }
                        ],
                        "id": "1799583486259212",
                        "is_deleted": false,
                        "name": "管步哲"
                    }
                ],
                "work_item_content": "【单城首店】M4优化新市场单城首店策略及标准，总结复制成功首店及品宣阁模式进行推广，Q2完成新区品宣阁XX家；"
            }
        ],
        // alignType: 'forward',
    }
]