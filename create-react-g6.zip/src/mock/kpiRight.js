export const rightChild = [
  {
    "id": "1803278288395322",
    "nodeType": "PROJECT",
    "userName": "司维坤",
    "userAvatar": {
      "color": null,
      "color_id": null,
      "content": null,
      "image": {
        "large": "https://s3-imfile.feishucdn.com/static-resource/v1/v3_007g_41528857-3b2e-466c-b764-0c8f8b8c469g~?image_size=noop&cut_type=&quality=&format=image&sticker_format=.webp"
      },
      "source": "image"
    },
    "content": "33",
    "list": [],
     // 新增字段
    //  alignType: 'backward',
  },
  {
    "id": "1802927753101577",
    "nodeType": "KPI",
    "userName": "魏志宇",
    "userAvatar": {
      "color": null,
      "color_id": null,
      "content": null,
      "image": {
        "large": "https://s3-imfile.feishucdn.com/static-resource/v1/v2_c2342e1b-133e-4fa8-87f0-f8bf227766eg~?image_size=noop&cut_type=&quality=&format=image&sticker_format=.webp"
      },
      "source": "image"
    },
    "content": "阿凡达阿凡达阿凡达阿凡达阿凡达阿凡达阿凡达阿凡达阿凡达阿凡达阿凡达阿凡达阿凡达阿凡达阿凡达阿凡达阿凡达阿凡达阿凡达阿凡达阿凡达阿凡达阿凡达阿凡达阿凡达阿凡达阿凡达阿凡达阿凡达阿凡达阿凡达阿凡达阿凡达阿凡达阿凡达阿凡达阿凡达阿凡达阿凡达",
    "list": [
      {
        "_id": 1802927492654507,
        "basic_value": "323232",
        "ceiling_value": null,
        "lowest_value": "3232",
        "work_item_content": "32"
      },
      {
        "_id": 1802927495268458,
        "basic_value": "323",
        "ceiling_value": null,
        "lowest_value": "3232",
        "work_item_content": "阿发阿发阿发阿发阿发阿发阿发阿发阿发阿发阿发阿发阿发阿发阿发阿发阿发阿发阿发阿发阿发阿发阿发阿发阿发阿发阿发阿发阿发阿发阿发阿发阿发阿发阿发阿发"
      }
    ],
     // 新增字段
    //  alignType: 'backward',
  },
  {
    "id": "1803523808856121",
    "nodeType": "KPI",
    "userName": "彭洁",
    "userAvatar": {
      "color": "#4871e9",
      "color_id": "R",
      "content": [
        {
          "language_code": 2052,
          "text": "彭洁"
        }
      ],
      "image": null,
      "source": "field"
    },
    "content": "1111111",
    "list": [
      {
        "_id": 1803523887103020,
        "basic_value": "1000",
        "ceiling_value": "0",
        "lowest_value": "2000",
        "work_item_content": "11"
      },
      {
        "_id": 1803528859517956,
        "basic_value": "4",
        "ceiling_value": "3",
        "lowest_value": "6",
        "work_item_content": "测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据测试数据"
      },
      {
        "_id": 1803530162514955,
        "basic_value": "-8",
        "ceiling_value": "-6",
        "lowest_value": "-2",
        "work_item_content": "22"
      }
    ],
     // 新增字段
    //  alignType: 'backward',
  },
  {
    "id": "1803805678563364",
    "nodeType": "OKR",
    "userName": "魏志宇",
    "userAvatar": {
      "color": null,
      "color_id": null,
      "content": null,
      "image": {
        "large": "https://s3-imfile.feishucdn.com/static-resource/v1/v2_c2342e1b-133e-4fa8-87f0-f8bf227766eg~?image_size=noop&cut_type=&quality=&format=image&sticker_format=.webp"
      },
      "source": "image"
    },
    "content": "完成品宣阁XX家，完成XX的租赁堂食比门店XX%；",
    "list": [
      {
        "_id": 1803803245636700,
        "director": {
          "avatar": {
            "color": null,
            "color_id": null,
            "content": null,
            "image": {
              "large": "https://s3-imfile.feishucdn.com/static-resource/v1/v2_c2342e1b-133e-4fa8-87f0-f8bf227766eg~?image_size=noop&cut_type=&quality=&format=image&sticker_format=.webp"
            },
            "source": "image"
          },
          "i18n_name": [
            {
              "language_code": 2052,
              "text": "魏志宇"
            }
          ],
          "id": 1799583243652140,
          "is_deleted": false,
          "name": "魏志宇"
        },
        "synergies": [
          {
            "avatar": {
              "color": null,
              "color_id": null,
              "content": null,
              "image": {
                "large": "https://s3-imfile.feishucdn.com/static-resource/v1/v3_007g_41528857-3b2e-466c-b764-0c8f8b8c469g~?image_size=noop&cut_type=&quality=&format=image&sticker_format=.webp"
              },
              "source": "image"
            },
            "i18n_name": [
              {
                "language_code": 2052,
                "text": "司维坤"
              }
            ],
            "id": 1799582925617267,
            "is_deleted": false,
            "name": "司维坤"
          },
          {
            "avatar": {
              "color": "#4871e9",
              "color_id": null,
              "content": null,
              "image": {
                "imageId": "825ca650d85448fb91257c84a09139e2_c",
                "large": "/img/223537/825ca650d85448fb91257c84a09139e2_l.jpg"
              },
              "source": "image"
            },
            "i18n_name": [
              {
                "language_code": 2052,
                "text": "管步哲"
              }
            ],
            "id": 1799583486259212,
            "is_deleted": false,
            "name": "管步哲"
          }
        ],
        "work_item_content": "【单城首店】M4优化新市场单城首店策略及标准，总结复制成功首店及品宣阁模式进行推广，Q2完成新区品宣阁XX家；"
      }
    ],
     // 新增字段
    //  alignType: 'backward',
  }
]