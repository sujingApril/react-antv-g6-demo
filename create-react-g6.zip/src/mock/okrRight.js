export const rightChild2 = [
  {
    id: "18032782883963221",
    nodeType: "PROJECT",
    userName: "魏志宇",
    userAvatar: {
      color: null,
      color_id: null,
      content: null,
      image: {
        large:
          "https://s3-imfile.feishucdn.com/static-resource/v1/v2_c2342e1b-133e-4fa8-87f0-f8bf227766eg~?image_size=noop&cut_type=&quality=&format=image&sticker_format=.webp",
      },
      source: "image",
    },
    content: "33",
    list: [],
    // 新增字段
    alignType: "backward",
  },
  {
    id: "18036889260821532",
    nodeType: "KPI",
    userName: "彭洁",
    userAvatar: {
      color: "#4871e9",
      color_id: "R",
      content: [
        {
          language_code: 2052,
          text: "彭洁",
        },
      ],
      image: null,
      source: "field",
    },
    content: "22",
    list: [
      {
        _id: "18036893237433481",
        basic_value: "2",
        ceiling_value: null,
        lowest_value: "1",
        work_item_content: "111",
      },
      {
        _id: "18036893486111291",
        basic_value: "4",
        ceiling_value: "2",
        lowest_value: "6",
        work_item_content: "33",
      },
      {
        _id: "18036895912694271",
        basic_value: "23",
        ceiling_value: null,
        lowest_value: "43",
        work_item_content: "222",
      },
    ],
    // 新增字段
    alignType: "backward",
  },
  {
    id: "18032903272161853",
    nodeType: "OKR",
    userName: "程泽华",
    userAvatar: {
      color: null,
      color_id: null,
      content: null,
      image: {
        large:
          "https://s1-imfile.feishucdn.com/static-resource/v1/v3_00br_c56b55c8-a4ee-41a1-b58f-52df6225b8ag~?image_size=noop&cut_type=&quality=&format=image&sticker_format=.webp",
      },
      source: "image",
    },
    content: "312312312321",
    list: [],
    // 新增字段
    alignType: "backward",
  },
];
