
export const leftChild2 = [
    {
        "id": "1803689807166516",
        "nodeType": "KPI",
        "userName": "彭洁",
        "userAvatar": {
            "color": "#4871e9",
            "color_id": "R",
            "content": [
                {
                    "language_code": 2052,
                    "text": "彭洁"
                }
            ],
            "image": null,
            "source": "field"
        },
        "content": "33",
        "list": [
            {
                "_id": "1803689351512115",
                "basic_value": "2",
                "ceiling_value": "3",
                "lowest_value": "1",
                "work_item_content": "33"
            },
            {
                "_id": "1803689410243603",
                "basic_value": "2",
                "ceiling_value": null,
                "lowest_value": "7",
                "work_item_content": "222"
            },
            {
                "_id": "1803689880488964",
                "basic_value": "2",
                "ceiling_value": "3",
                "lowest_value": "1",
                "work_item_content": "111"
            }
        ],
        // 新增字段
        alignType: 'forward',
    },
    {
        "id": "1803782147722240",
        "nodeType": "KPI",
        "userName": "魏志宇",
        "userAvatar": {
            "color": null,
            "color_id": null,
            "content": null,
            "image": {
                "large": "https://s3-imfile.feishucdn.com/static-resource/v1/v2_c2342e1b-133e-4fa8-87f0-f8bf227766eg~?image_size=noop&cut_type=&quality=&format=image&sticker_format=.webp"
            },
            "source": "image"
        },
        "content": "111",
        "list": [
            {
                "_id": "11803794807899161",
                "basic_value": "22",
                "ceiling_value": "1111",
                "lowest_value": "2",
                "work_item_content": "反反复复付反反复复付反反复复付反反复复付反反复复付反反复复付反反复复付反反复复付反反复复付反反复复付反反复复付反反复复付"
            },
            {
                "_id": "18203794807899161",
                "basic_value": "22",
                "ceiling_value": "1111",
                "lowest_value": "2",
                "work_item_content": "反反复复付反反复复付反反复复付反反复复付反反复复付反反复复付反反复复付反反复复付反反复复付反反复复付反反复复付反反复复付"
            },
            {
                "_id": "18033794807899161",
                "basic_value": "22",
                "ceiling_value": "1111",
                "lowest_value": "2",
                "work_item_content": "反反复复付反反复复付反反复复付反反复复付反反复复付反反复复付反反复复付反反复复付反反复复付反反复复付反反复复付反反复复付"
            }
        ],
        // 新增字段
        alignType: 'forward',
    },
    {
        "id": "1803290282309643",
        "nodeType": "OKR",
        "userName": "程泽华",
        "userAvatar": {
            "color": null,
            "color_id": null,
            "content": null,
            "image": {
                "large": "https://s1-imfile.feishucdn.com/static-resource/v1/v3_00br_c56b55c8-a4ee-41a1-b58f-52df6225b8ag~?image_size=noop&cut_type=&quality=&format=image&sticker_format=.webp"
            },
            "source": "image"
        },
        "content": "1321312312313123213",
        "list": [],
        // 新增字段
        alignType: 'forward',
    },
    {
        "id": "1803365610066953",
        "nodeType": "OKR",
        "userName": "李文良",
        "userAvatar": {
            "color": null,
            "color_id": null,
            "content": null,
            "image": {
                "large": "https://s3-imfile.feishucdn.com/static-resource/v1/v3_009f_ad73f0fa-3fe3-4190-802f-1ddc36642b6g~?image_size=noop&cut_type=&quality=&format=image&sticker_format=.webp"
            },
            "source": "image"
        },
        "content": "2",
        "list": [],
        // 新增字段
        alignType: 'forward',
    }
]